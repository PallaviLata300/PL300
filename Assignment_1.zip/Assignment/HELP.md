# Requirement
1. Spring Boot based application creation. Only backend is needed. Basic HTML front end
may be provided at your discretion but is not mandatory.

2. Create an API for Users to sign up. Capture standard fields during signup. Implement
some password strength checks which can be determined by you.

3. Create an API for Users to login, it will take username and password and verify if the
combination is present in User table database, if yes then return JWT authToken.

4. Implement Spring security.

5. Create an API for Users to add their profile details (full name, phone, address etc ) into
Profile table. Pick 5-8 fields of your choice.

6. Create API to add Departments in Department Table.

7. Create an API to associate the Users to a Department.

8. Write rest APIs for CRUD operation on Department .

# Steps to Run
### Database Setup
- CREATE DATABASE `wesay_schema`;
- create mysql server with user=root and password=root

- DROP TABLE `user`;
- DROP TABLE `department`;
- DDL statement
    - department table	
        ```sql 
        CREATE TABLE `department` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `department_name` varchar(50) unique NOT NULL,
          `department_detail` varchar(255) DEFAULT NULL,
          PRIMARY KEY (`id`)
        );
        ```

    - samples departments (DML)
        ```sql
insert into department(department_name, department_detail) values ("test1DeptName", "Department detail test1 example");
insert into department(department_name, department_detail) values ("test2DeptName", "Department detail test2 example");
        ```
    - user table
        ```sql
        CREATE TABLE `user` (
          `id` int(11) NOT NULL AUTO_INCREMENT,
          `first_name` varchar(50) NOT NULL,
          `last_name` varchar(50) NOT NULL,
          `email` varchar(50) NOT NULL,
          `password` varchar(100) NOT NULL,
          `contact` varchar(15) DEFAULT NULL,
          `address` varchar(100) DEFAULT NULL,
          `department_id` int(11) DEFAULT NULL,
          `gender` varchar(15) DEFAULT NULL
          PRIMARY KEY (`id`),
          FOREIGN KEY (department_id) REFERENCES department(id)
        );
        ```
 
### Application Config Check

1. Update mysql url, password and username same as your install mysql password in your application.properties
    > example: 
      - spring.datasource.url=jdbc:mysql://localhost:3306/wesay_schema?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC
      - spring.datasource.username=root
      - spring.datasource.password=root
      
### Api Details

1. Users Api

    -   Post /user/registration
    -   Post /user/login 
    -   Put /user/update
    -   Get /user/departmentName
    -   Get /user/email/departmentName

2. Departments Api

    -   Post /department/create
    -   Get /department/id
    -   Get /department/all
    -   Put /department/id
    -   Delete /department/id


#### Api Description
1. post /user/registration
    - Description: This api will create user and return user details in response with 
    access token in headers.
    - post body
    ```json
    {
        "firstName": "pal",
        "lastName": "lata",
        "email": "pkumar1@gmail.com",
        "password": "Kal#3003",
        "passwordConfirm": "Kal#3003",
        "address": "ak",
        "contact": "8130640508",
        "departmentId": 1,
        "gender": "female"
    }
    ```
    
2. /user/login
    - Description: This Api will authorize user using username and password.
    - post body
    ```json
    {
        "email": "pkumar1@gmail.com",
        "password": "Kal#3003"
    }
    ```

3. /user/update
   - Description: This api will update user details;
   - Authenticated api, pass token in api headers
   - Put body
   ```json
     {
         "firstName": "pal",
         "lastName": "lata1",
         "email": "pkumar1@gmail.com",
         "password": "Kal#3003",
         "passwordConfirm": "Kal#3003",
         "address": "ak",
         "contact": "8130640508",
         "departmentId": 1,
         "gender": "female"
     }
    ```

4. /department/create
    - Description:  This api will create department and return department info.
    - Authenticated api, pass token in api headers
    - Post body
    ```json
    {
            "departmentName": "pal30",
            "departmentDetail": "pal"
    }
    ```
    
5. /department/id
    - method: Get
    - Description: This api will return department info of corresponding id.
    
6. /department/all
    - method: Get
    - Description: This api will return list of all department.


7. /department/id
    - method: Put
    - Description: This api will update the department info.
    ```json
    {
            "departmentName": "pal301",
            "departmentDetail": "pal1"
    }
    ```

8. /department/id
    - method: Delete
    - Description: This api will delete the department from the storage

9. /user/department?department=test1DeptName
    - method: Get
    - Description: This api will return list of user who belongs to same department
