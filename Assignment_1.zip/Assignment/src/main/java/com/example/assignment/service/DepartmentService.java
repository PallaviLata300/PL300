package com.example.assignment.service;


import com.example.assignment.exceptions.DepartmentException;
import com.example.assignment.model.Department;
import com.example.assignment.model.DepartmentDetailRequestModel;
import org.springframework.http.ResponseEntity;

import java.util.List;


public interface DepartmentService {

  Department createDepartment(DepartmentDetailRequestModel departmentDetailRequestModel) throws DepartmentException;

  Department updateDepartment(DepartmentDetailRequestModel departmentDetailRequestModel, long id) throws DepartmentException;

  ResponseEntity<Object> deleteDepartment(long id);

  Department getDepartment(long id) throws DepartmentException;

  List<Department> getDepartment();
}

