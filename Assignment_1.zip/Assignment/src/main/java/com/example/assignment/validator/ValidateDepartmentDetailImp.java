package com.example.assignment.validator;

import com.example.assignment.exceptions.DepartmentException;
import org.springframework.stereotype.Service;

@Service
public class ValidateDepartmentDetailImp implements ValidateDepartmentDetail {

  @Override
  public void validatDepartment(String department) throws DepartmentException {
    if (department == null) throw new DepartmentException("first name is null");

  }

}
