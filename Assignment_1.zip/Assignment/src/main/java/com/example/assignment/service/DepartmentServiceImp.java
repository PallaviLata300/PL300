package com.example.assignment.service;


import com.example.assignment.exceptions.DepartmentException;
import com.example.assignment.model.Department;
import com.example.assignment.model.DepartmentDetailRequestModel;
import com.example.assignment.repository.DepartmentRepository;
import com.example.assignment.validator.ValidateDepartmentDetail;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImp implements DepartmentService {
  @Autowired
  private DepartmentRepository departmentRepository;
  @Autowired
  private ValidateDepartmentDetail validateDepartmentDetail;


  @Override
  public Department createDepartment(DepartmentDetailRequestModel departmentDetail) throws DepartmentException {
    //validate input
    Department department = new Department();
    validateDepartmentDetail.validatDepartment(departmentDetail.getDepartmentName());
    BeanUtils.copyProperties(departmentDetail, department);

    //Input verified
    departmentRepository.save(department);
    return department;
  }


  @Override
  public Department updateDepartment(DepartmentDetailRequestModel departmentDetail, long id) throws DepartmentException {
    Department department = departmentRepository.findById(id)
            .orElseThrow(() -> new DepartmentException("Department not found"));

    department.setDepartmentName(departmentDetail.getDepartmentName());
    department.setDepartmentDetail(departmentDetail.getDepartmentDetail());
    departmentRepository.save(department);
    return department;
  }

  @Override
  public ResponseEntity<Object> deleteDepartment(long id) {
    departmentRepository.deleteById(id);
    return new ResponseEntity<Object>(HttpStatus.ACCEPTED);
  }

  @Override
  public Department getDepartment(long id) throws DepartmentException {
    return departmentRepository.findById(id)
            .orElseThrow(() -> new DepartmentException("Department not found"));
  }

  @Override
  public List<Department> getDepartment() {
    return departmentRepository.findAll();
  }
}
