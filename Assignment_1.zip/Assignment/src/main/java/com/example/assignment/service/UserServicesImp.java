package com.example.assignment.service;


import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.assignment.exceptions.UserException;
import com.example.assignment.model.User;
import com.example.assignment.model.UserDetailRequestModel;
import com.example.assignment.repository.UserRepository;
import com.example.assignment.validator.ValidateUserDetails;


@Service
public class UserServicesImp implements UserService {
  @Autowired
  private UserRepository userRepository;
  @Autowired
  private ValidateUserDetails validateUserDetail;
  @Autowired
  private BCryptPasswordEncoder bCryptPasswordEncoder;


  @Override
  public User createUser(UserDetailRequestModel userDetail) throws UserException {
    //validate input
    User user = new User();
    validateUserDetail.validatePassword(userDetail.getPassword(), userDetail.getPasswordConfirm());
    validateUserDetail.validateFirstName(userDetail.getFirstName());
    validateUserDetail.validateLastName(userDetail.getLastName());
    validateUserDetail.validateEmail(userDetail.getEmail());
    userDetail.setPassword(bCryptPasswordEncoder.encode(userDetail.getPassword()));
    BeanUtils.copyProperties(userDetail, user);

    //Input verified
    userRepository.save(user);
    return user;
  }

  @Override
  public User updateUser(UserDetailRequestModel userDetail, String email) throws UserException {
    User user = userRepository.findByEmail(email);
    if (user == null) throw new UserException(email + " is not registered!!!");
    user.setFirstName(userDetail.getFirstName());
    user.setLastName(userDetail.getLastName());
    user.setAddress(userDetail.getAddress());
    user.setContact(userDetail.getContact());
    user.setDepartmentId(userDetail.getDepartmentId());
    user.setGender(userDetail.getGender());

    userRepository.save(user);
    return user;
  }

  @Override
  @Transactional(readOnly = true)
  public User loginUser(String email, String password) throws UserException {
    User user = userRepository.findByEmail(email);
    if (user == null) throw new UserException(email + " is not registered!!!");

    if (bCryptPasswordEncoder.matches(password, user.getPassword())) {
      return user;
    }
    throw new UserException("For Email:" + email + " Password is wrong!!!");

  }

  @Override
  public List<User> getUsersByDepartmentName(String departmentName) {
    return userRepository.getUserByDepartmentName(departmentName);
  }

  @Override
  public List<String> getUsersEmailByDepartmentName(String departmentName) {
    return userRepository.getUserEmailByDepartmentName(departmentName);}


}
