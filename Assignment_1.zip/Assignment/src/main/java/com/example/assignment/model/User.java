package com.example.assignment.model;

//import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.io.Serializable;

@Entity
@Table(name = "user")
//@Data
public class User implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(nullable = false, length = 50)
  private String firstName;

  @Column(nullable = false, length = 50)
  private String lastName;

  @Email
  @Column(nullable = false, length = 50, unique = true)
  private String email;

  @Column(nullable = false, length = 50)
  private String password;

  @Column(length = 100)
  private String contact;

  @Column(length = 15)
  private String address;

  @Column(length = 100)
  private Long departmentId;

  @Column(length=15)
  private String gender;


public Long getId() {
	return id;
}



public void setId(Long id) {
	this.id = id;
}



public String getFirstName() {
	return firstName;
}



public void setFirstName(String firstName) {
	this.firstName = firstName;
}



public String getLastName() {
	return lastName;
}



public void setLastName(String lastName) {
	this.lastName = lastName;
}



public String getEmail() {
	return email;
}



public void setEmail(String email) {
	this.email = email;
}



public String getPassword() {
	return password;
}



public void setPassword(String password) {
	this.password = password;
}



public String getContact() {
	return contact;
}



public void setContact(String contact) {
	this.contact = contact;
}



public String getAddress() {
	return address;
}



public void setAddress(String address) {
	this.address = address;
}



public Long getDepartmentId() {
	return departmentId;
}



public void setDepartmentId(Long departmentId) {
	this.departmentId = departmentId;
}



public String getGender() {
	return gender;
}



public void setGender(String gender) {
	this.gender = gender;
}





public static long getSerialVersionUID() {
    return serialVersionUID;
  }
}
