package com.example.assignment.controller;

import com.example.assignment.exceptions.UserException;
import com.example.assignment.model.User;
import com.example.assignment.model.UserDetailRequestModel;
import com.example.assignment.security.JwtTokenProvider;
import com.example.assignment.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/user")
public class UserController {
  @Autowired
  private UserService userService;

  @Autowired
  private JwtTokenProvider jwtTokenProvider;

  /**
   * @Description: This api will check user is authorized or not to access the underline resource
   * @param userDetail
   * @return User detail
   * @throws UserException
   */
  @PostMapping(path = "/login",
          consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE},
          produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE})
  public ResponseEntity<User> login(@RequestBody UserDetailRequestModel userDetail) throws UserException {
    User user = userService.loginUser(userDetail.getEmail(), userDetail.getPassword());
    // generate token and return in headers
    String token = jwtTokenProvider.createToken(userDetail.getEmail(), null);
    HttpHeaders responseHeaders = new HttpHeaders();
    responseHeaders.set("token", token);
    return new ResponseEntity<>(user, responseHeaders, HttpStatus.OK);
  }

  /**
   * @Description This api will create user and return user details in response with access token in headers.
   * @param userDetail
   * @return user details with access token in headers
   * @throws UserException
   */
  @PostMapping(path = "/registration",
          consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE},
          produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE})
  public ResponseEntity<User> createUser(@RequestBody UserDetailRequestModel userDetail) throws UserException {
    User createdUser = userService.createUser(userDetail);
    // generate token and return in headers
    HttpHeaders responseHeaders = new HttpHeaders();
    String token = jwtTokenProvider.createToken(userDetail.getEmail(), null);
    responseHeaders.set("token", token);
    return new ResponseEntity<>(createdUser, responseHeaders, HttpStatus.OK);
  }

  /**
   * @Description: This api will update the user existing data
   * @param userDetail
   * @return updated user
   * @throws UserException
   */
  @PutMapping(path = "/update",
          consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE},
          produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE})
  public @ResponseBody
  User updateUserById(@RequestBody UserDetailRequestModel userDetail) throws UserException {
    return userService.updateUser(userDetail, userDetail.getEmail());
  }

  /**
   * @Description: This api will delete the user by id from the database
   * @return user deleted status
   */
  @DeleteMapping(path = "/{id}")
  public @ResponseBody
  String deleteUserById(@PathVariable long id) {
    return "Delete user is not part of assignment!!!";
  }

  /**
   * @param departmentName
   * @return list of users
   */
  @GetMapping(path = "/{departmentName}")
  public List<User> getUsersByDepartmentName(@PathVariable String departmentName) {
    return userService.getUsersByDepartmentName(departmentName);
  }
  
  @GetMapping(path = "/email/{departmentName}")
  public List<String> getUsersEmailByDepartmentName(@PathVariable String departmentName) {
    return userService.getUsersEmailByDepartmentName(departmentName);
  }

}
