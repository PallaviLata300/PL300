package com.example.assignment.service;

import com.example.assignment.exceptions.UserException;
import com.example.assignment.model.User;
import com.example.assignment.model.UserDetailRequestModel;

import java.util.List;

public interface UserService {

  User createUser(UserDetailRequestModel userDetail) throws UserException;

  User loginUser(String email, String password) throws UserException;

  User updateUser(UserDetailRequestModel userDetail, String email) throws UserException;

  List<User> getUsersByDepartmentName(String departmentName);

  List<String> getUsersEmailByDepartmentName(String departmentName);

}
