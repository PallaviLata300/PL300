package com.example.assignment.validator;

import com.example.assignment.exceptions.UserException;

public interface ValidateUserDetails {
  void validateEmail(String email) throws UserException;

  void validatePassword(String password, String confirmPassword) throws UserException;

  void validateFirstName(String firstName) throws UserException;

  void validateLastName(String lastName) throws UserException;
}
