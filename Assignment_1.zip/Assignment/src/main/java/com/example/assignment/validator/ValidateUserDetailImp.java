package com.example.assignment.validator;

import com.example.assignment.exceptions.UserException;
import com.example.assignment.model.User;
import com.example.assignment.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ValidateUserDetailImp implements ValidateUserDetails {
  @Autowired
  private UserRepository userRepository;

  @Override
  public void validateFirstName(String firstName) throws UserException {
    if (firstName == null) throw new UserException("first name is null!");
  }

  @Override
  public void validateLastName(String lastName) throws UserException {
    if (lastName == null) throw new UserException("Last name is null!");
  }

  @Override
  public void validatePassword(String password, String confirmPassword) throws UserException {
    if (password == null) throw new UserException("password is null!");
    if (password.length() < 8) throw new UserException("password is weak!");
    if (!password.equals(confirmPassword))
      throw new UserException("password and confirm password not matching!");
  }

  @Override
  public void validateEmail(String email) throws UserException {
    if (email == null) throw new UserException("Email is null!");
    User user = userRepository.findByEmail(email);
    if (user != null) throw new UserException(email + " is already registered!");
  }
}
