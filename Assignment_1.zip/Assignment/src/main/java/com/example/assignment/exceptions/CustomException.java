package com.example.assignment.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class CustomException {
  @ExceptionHandler(UserException.class)
  public ResponseEntity<Object> errorMessage(UserException e) {
    return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
  }


  @ExceptionHandler(DepartmentException.class)
  public ResponseEntity<Object> errorMessage(DepartmentException e) {
    return new ResponseEntity<Object>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
  }
}
