package com.example.assignment.model;

//import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "department")
//@Data
public class Department {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  @Column(length = 50)
  private String departmentName;

  @Column(length = 225)
  private String departmentDetail;

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getDepartmentName() {
	return departmentName;
}

public void setDepartmentName(String departmentName) {
	this.departmentName = departmentName;
}

public String getDepartmentDetail() {
	return departmentDetail;
}

public void setDepartmentDetail(String departmentDetail) {
	this.departmentDetail = departmentDetail;
}
  
}
