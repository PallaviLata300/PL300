package com.example.assignment.validator;

import com.example.assignment.exceptions.DepartmentException;

public interface ValidateDepartmentDetail {
  void validatDepartment(String department) throws DepartmentException;
}
