package com.example.assignment.model;

//import lombok.Data;

import java.io.Serializable;

//@Data
public class DepartmentDetailRequestModel implements Serializable {

  private static final long serialVersionUID = 1L;
  private String departmentName;
  private String departmentDetail;
public String getDepartmentName() {
	return departmentName;
}
public void setDepartmentName(String departmentName) {
	this.departmentName = departmentName;
}
public String getDepartmentDetail() {
	return departmentDetail;
}
public void setDepartmentDetail(String departmentDetail) {
	this.departmentDetail = departmentDetail;
}
  

}
