package com.example.assignment.exceptions;

public class UserException extends Exception {

  private static final long serialVersionUID = 1L;

  public UserException() {
    super("invalid data entered");
  }

  public UserException(String errorMessage) {
    super(errorMessage);
  }

}
