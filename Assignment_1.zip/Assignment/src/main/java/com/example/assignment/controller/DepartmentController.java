package com.example.assignment.controller;

import com.example.assignment.exceptions.DepartmentException;
import com.example.assignment.model.Department;
import com.example.assignment.model.DepartmentDetailRequestModel;
import com.example.assignment.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/department")
public class DepartmentController {
  @Autowired
  private DepartmentService departmentService;

//------------------GET DEPARTMENT DETAIL USING DEPARTMENT ID --------------------------------------

  @GetMapping(path = "/{id}",
          produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE})
  public @ResponseBody
  Department getDepartment(@PathVariable long id) throws DepartmentException {
    return departmentService.getDepartment(id);
  }

//------------------GET ALL DEPARTMENT DETAIL ------------------------------------------------------

  @GetMapping(path = "/all",
          produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE})
  public @ResponseBody
  List<Department> getDepartment() {
    return departmentService.getDepartment();
  }

//------------------ADD DEPARTMENT INTO DEPARTMENT TABLE---------------------------------------------

  @PostMapping(path = "/create",
          consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE})
  public @ResponseBody
  Department createDepartment
          (@RequestBody DepartmentDetailRequestModel departmentDetail) throws DepartmentException {
    Department createdDepartment = departmentService.createDepartment(departmentDetail);
    return createdDepartment;
  }

//-----------------UPDATE DEPARTMENT INTO DEPARTMENT TABLE BY ID--------------------------------------

  @PutMapping(path = "/{id}",
          consumes = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_ATOM_XML_VALUE})
  public @ResponseBody
  Department updateDepartmentbyId
          (@RequestBody DepartmentDetailRequestModel departmentDetail, @PathVariable long id) throws DepartmentException {
    return departmentService.updateDepartment(departmentDetail, id);
  }

  //------------------DELETE DEPARTMENT INTO DEPARTMENT TABLE BY ID-----------------------------------------
  @DeleteMapping(path = "/{id}")
  public @ResponseBody
  ResponseEntity<Object> deleteDepartmentbyId(@PathVariable long id) {
    return departmentService.deleteDepartment(id);
  }
}
